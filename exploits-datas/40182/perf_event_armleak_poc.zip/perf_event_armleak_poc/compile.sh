#!/bin/sh
arm-linux-gnueabi-gcc -std=gnu99 -Wall -o poc poc.c -static
